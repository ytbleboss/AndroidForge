# Appel Plus by ZelnoX — version interface & téléphonie 1.3

Améliorations incluses dans cette archive :
- Icône de lancement personnalisée Appel Plus intégrée aux ressources Android.
- Interface Compose améliorée (clavier, contacts, journal et options visuelles persistantes).
- Déclaration d’un service `InCallService` et d’un écran d’appel entrant/sortant avec commandes décrocher/refuser/terminer.
- Option dans Paramètres pour demander à Android de définir Appel Plus comme application téléphonique par défaut (RoleManager sur Android 10+, écran système sur versions antérieures).
- Préférence d’enregistrement affichée dans les paramètres et action dédiée dans l’écran d’appel.

## Limite importante concernant l’enregistrement
L’API Android standard `InCallService` permet de gérer les appels, mais n’expose pas de façon générale le flux audio téléphonique distant pour l’enregistrer. La commande d’enregistrement indique donc explicitement cette limitation et ne prétend pas produire un fichier audio. La disponibilité dépend de la version Android, du fabricant, des autorisations privilégiées et des lois locales. L’enregistrement avant décroché n’est pas garanti.

## Compilation APK
1. Ouvrir le dossier dans Android Studio avec Android SDK Platform 35.
2. Synchroniser Gradle (connexion internet nécessaire pour les dépendances).
3. Build > Build APK(s).
APK debug attendu : `app/build/outputs/apk/debug/app-debug.apk`.

## Permissions et rôle
Le système doit accorder les autorisations nécessaires et l’utilisateur doit accepter explicitement la demande d’application téléphonique par défaut. La disponibilité des commandes et la gestion complète des écrans d’appel varient selon Android et l’appareil.
