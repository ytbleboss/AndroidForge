package com.zelnox.appelplus

import android.content.Intent
import android.telecom.Call
import android.telecom.InCallService

class AppelPlusInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        IncomingCallActivity.activeCall = call
        val intent = Intent(this, IncomingCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            .putExtra("incoming", call.state == Call.STATE_RINGING)
        try { startActivity(intent) } catch (_: Exception) { }
    }

    override fun onCallRemoved(call: Call) {
        if (IncomingCallActivity.activeCall === call) IncomingCallActivity.activeCall = null
        super.onCallRemoved(call)
    }
}
