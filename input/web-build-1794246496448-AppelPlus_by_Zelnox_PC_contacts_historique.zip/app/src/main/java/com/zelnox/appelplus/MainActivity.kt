package com.zelnox.appelplus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.content.Context
import android.provider.ContactsContract
import android.provider.CallLog
import android.telecom.TelecomManager
import android.app.role.RoleManager
import android.os.Build
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Back = Color(0xFF070B14)
private val Panel = Color(0xFF111A2B)
private val Panel2 = Color(0xFF17243A)
private val Blue = Color(0xFF35B7FF)
private val Blue2 = Color(0xFF5B72FF)
private val Mint = Color(0xFF31E6A4)
private val White = Color(0xFFF2F6FF)
private val Muted = Color(0xFF91A0B8)

data class Entry(val name: String, val phone: String)

class MainActivity : ComponentActivity() {
    private var queuedCall by mutableStateOf("")
    private val contacts = mutableStateListOf<Entry>()
    private val recents = mutableStateListOf<Entry>()

    private val callPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) makeCall(queuedCall) else toast("Permission d'appel refusée")
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadContacts() else toast("Permission Contacts refusée")
    }
    private val logsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadRecents() else toast("Permission journal d'appels refusée")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("appelplus", MODE_PRIVATE)
        setContent {
            var dial by remember { mutableStateOf("") }
            var tab by remember { mutableStateOf("Clavier") }
            var spam by remember { mutableStateOf(prefs.getBoolean("spam", true)) }
            var blueGlow by remember { mutableStateOf(prefs.getBoolean("glow", true)) }
            var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", true)) }
            var privacy by remember { mutableStateOf(prefs.getBoolean("privacy", false)) }
            var compact by remember { mutableStateOf(prefs.getBoolean("compact", false)) }
            var smartDial by remember { mutableStateOf(prefs.getBoolean("smartdial", true)) }
            var recording by remember { mutableStateOf(prefs.getBoolean("recording", false)) }

            MaterialTheme {
                Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0A1222), Back, Color(0xFF05070D))))) {
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
                        Header()
                        Spacer(Modifier.height(15.dp))
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel.copy(alpha=.94f)).padding(5.dp),
                            horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                            listOf("Clavier", "Contacts", "Journal", "Options").forEach { t ->
                                val selected = tab == t
                                Column(Modifier.weight(1f).clip(RoundedCornerShape(13.dp))
                                    .background(if(selected) Brush.horizontalGradient(listOf(Blue.copy(alpha=.25f), Blue2.copy(alpha=.20f))) else Brush.horizontalGradient(listOf(Panel,Panel)))
                                    .clickable {
                                        tab=t
                                        when(t) {
                                            "Contacts" -> if(checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED) loadContacts() else contactsPermission.launch(Manifest.permission.READ_CONTACTS)
                                            "Journal" -> if(checkSelfPermission(Manifest.permission.READ_CALL_LOG)==PackageManager.PERMISSION_GRANTED) loadRecents() else logsPermission.launch(Manifest.permission.READ_CALL_LOG)
                                        }
                                    }.padding(vertical=10.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                                    Text(when(t){"Clavier"->"⌗";"Contacts"->"♙";"Journal"->"◷";else->"⚙"}, color=if(selected) Blue else Muted, fontSize=17.sp)
                                    Text(t, color=if(selected) White else Muted, fontSize=10.sp, fontWeight=if(selected) FontWeight.Bold else FontWeight.Medium)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        when(tab) {
                            "Clavier" -> Dialer(dial, { dial=it }, blueGlow, vibration, compact, privacy,
                                onCall={ if(dial.isBlank()) toast("Compose un numéro") else { queuedCall=dial; if(checkSelfPermission(Manifest.permission.CALL_PHONE)==PackageManager.PERMISSION_GRANTED) makeCall(dial) else callPermission.launch(Manifest.permission.CALL_PHONE) } },
                                onMessage={ if(dial.isBlank()) toast("Compose un numéro") else try { startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(dial)}"))) } catch(_:Exception) { toast("Application SMS introuvable") } },
                                onBackspace={ if(dial.isNotEmpty()) dial=dial.dropLast(1) })
                            "Contacts" -> EntriesList(contacts, "Tes contacts", "Contacts autorisés", { dial=it; tab="Clavier" })
                            "Journal" -> EntriesList(recents, "Appels récents", "Historique du téléphone", { dial=it; tab="Clavier" })
                            else -> Options(spam,blueGlow,vibration,privacy,compact,smartDial,recording,
                                {spam=it;prefs.edit().putBoolean("spam",it).apply()},
                                {blueGlow=it;prefs.edit().putBoolean("glow",it).apply()},
                                {vibration=it;prefs.edit().putBoolean("vibration",it).apply()},
                                {privacy=it;prefs.edit().putBoolean("privacy",it).apply()},
                                {compact=it;prefs.edit().putBoolean("compact",it).apply()},
                                {smartDial=it;prefs.edit().putBoolean("smartdial",it).apply()},
                                {recording=it;prefs.edit().putBoolean("recording",it).apply()},
                                { requestDefaultDialer() })
                        }
                    }
                }
            }
        }
    }

    @Composable private fun Header() {
        Row(verticalAlignment=Alignment.CenterVertically, modifier=Modifier.fillMaxWidth()) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Blue,Blue2))), contentAlignment=Alignment.Center) {
                Text("Z+", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Black)
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text("Appel +", color=White, fontSize=27.sp, fontWeight=FontWeight.ExtraBold, letterSpacing=(-.5).sp)
                Text("BY ZELNOX  •  SMART PHONE", color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.4.sp)
            }
            Spacer(Modifier.weight(1f))
            Column(horizontalAlignment=Alignment.End) {
                Row(verticalAlignment=Alignment.CenterVertically) { Box(Modifier.size(7.dp).clip(CircleShape).background(Mint)); Spacer(Modifier.width(5.dp)); Text("SIM ACTIVE", color=Mint, fontSize=9.sp, fontWeight=FontWeight.Bold) }
                Text("Appels opérateur", color=Muted, fontSize=10.sp)
            }
        }
    }

    @Composable private fun Dialer(number:String, change:(String)->Unit, glow:Boolean, haptic:Boolean, compact:Boolean, privacy:Boolean, onCall:()->Unit, onMessage:()->Unit, onBackspace:()->Unit) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), horizontalAlignment=Alignment.CenterHorizontally) {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Panel2,Panel)))
                .border(1.dp,Blue.copy(alpha=if(glow).42f else .12f),RoundedCornerShape(24.dp)).padding(horizontal=18.dp, vertical=if(compact) 14.dp else 20.dp)) {
                Column {
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("NUMÉRO À COMPOSER", color=Muted, fontSize=9.sp, fontWeight=FontWeight.Bold, letterSpacing=1.6.sp)
                        Spacer(Modifier.weight(1f))
                        Text("● CHIFFREMENT UI", color=Blue.copy(alpha=.8f), fontSize=8.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    BasicTextField(number, change, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),
                        textStyle=TextStyle(color=White,fontSize=30.sp,fontWeight=FontWeight.SemiBold,letterSpacing=1.sp),singleLine=true, visualTransformation=if(privacy) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
                        decorationBox={ inner -> Box { if(number.isEmpty()) Text("+33 · · · · · · · · ·",color=Muted.copy(alpha=.65f),fontSize=27.sp); inner() } }, modifier=Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("SIM habituelle",color=Muted,fontSize=11.sp)
                        Spacer(Modifier.width(7.dp)); Box(Modifier.clip(CircleShape).background(Color(0xFF233C59)).padding(horizontal=9.dp,vertical=4.dp)) { Text("Voix 4G / opérateur",color=Blue,fontSize=9.sp,fontWeight=FontWeight.Bold) }
                        Spacer(Modifier.weight(1f)); Text("⌫",color=Blue,fontSize=19.sp,modifier=Modifier.clickable { onBackspace() }.padding(horizontal=7.dp))
                        Text("Effacer",color=Muted,fontSize=10.sp,modifier=Modifier.clickable { change("") })
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            val keys=listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
            keys.chunked(3).forEach { row ->
                Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    row.forEach { (digit,letters) ->
                        Column(Modifier.weight(1f).padding(bottom=9.dp).height(if(compact) 54.dp else 61.dp)
                            .clip(RoundedCornerShape(18.dp)).background(Brush.verticalGradient(listOf(Panel2,Panel)))
                            .border(1.dp,Blue.copy(alpha=if(glow).20f else .07f),RoundedCornerShape(18.dp))
                            .clickable { change(number+digit); if(haptic) vibrate() }, horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center) {
                            Text(digit,color=White,fontSize=24.sp,fontWeight=FontWeight.SemiBold)
                            if(letters.isNotEmpty()) Text(letters,color=Muted,fontSize=8.sp,letterSpacing=1.8.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp),verticalAlignment=Alignment.CenterVertically) {
                Box(Modifier.size(54.dp).clip(CircleShape).background(Panel2).clickable { onMessage() },contentAlignment=Alignment.Center) { Text("▤",color=Blue,fontSize=22.sp) }
                Box(Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(30.dp)).background(Brush.horizontalGradient(listOf(Color(0xFF00C98A),Color(0xFF25E5B0))))
                    .clickable { onCall() },contentAlignment=Alignment.Center) { Row(verticalAlignment=Alignment.CenterVertically) { Text("☎",color=Color(0xFF06241B),fontSize=22.sp); Spacer(Modifier.width(10.dp)); Text("APPELER",color=Color(0xFF06241B),fontSize=16.sp,fontWeight=FontWeight.ExtraBold,letterSpacing=1.sp) } }
                Box(Modifier.size(54.dp).clip(CircleShape).background(Panel2).clickable { onBackspace() },contentAlignment=Alignment.Center) { Text("⌫",color=Muted,fontSize=22.sp) }
            }
            Spacer(Modifier.height(10.dp))
            Text("Les appels passent par ta carte SIM et ton opérateur.",color=Muted,fontSize=10.sp,textAlign=TextAlign.Center)
        }
    }

    @Composable private fun Options(spam:Boolean,glow:Boolean,vibration:Boolean,privacy:Boolean,compact:Boolean,smartDial:Boolean,recording:Boolean,
        setSpam:(Boolean)->Unit,setGlow:(Boolean)->Unit,setVibration:(Boolean)->Unit,setPrivacy:(Boolean)->Unit,setCompact:(Boolean)->Unit,setSmart:(Boolean)->Unit,setRecording:(Boolean)->Unit,onDefaultDialer:()->Unit) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
            Text("PERSONNALISATION",color=Blue,fontSize=10.sp,fontWeight=FontWeight.Bold,letterSpacing=1.8.sp)
            Text("Ton téléphone. Tes règles.",color=White,fontSize=23.sp,fontWeight=FontWeight.Bold)
            Text("Les préférences sont enregistrées sur cet appareil.",color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            SettingRow("Effets néon bleus","Ambiance lumineuse futuriste",glow,setGlow,"✦")
            SettingRow("Retour haptique","Vibration légère au clavier",vibration,setVibration,"〰")
            SettingRow("Mode compact","Touches et espacements réduits",compact,setCompact,"▦")
            SettingRow("Composition intelligente","Préférence d'assistance de saisie",smartDial,setSmart,"⌕")
            SettingRow("Mode discret","Masquer les chiffres pendant la saisie",privacy,setPrivacy,"◉")
            SettingRow("Protection anti-spam","Option visuelle — ne filtre pas les appels système",spam,setSpam,"⛨")
            SettingRow("Enregistrement d’appel","Préférence activée — Android/OEM peut bloquer l’audio des appels",recording,setRecording,"●")
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel2).border(1.dp,Blue.copy(alpha=.35f),RoundedCornerShape(16.dp)).clickable { onDefaultDialer() }.padding(15.dp)) {
                Column {
                    Text("APPLICATION TÉLÉPHONIQUE",color=Blue,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.4.sp)
                    Spacer(Modifier.height(5.dp)); Text("Définir Appel Plus par défaut",color=White,fontSize=14.sp,fontWeight=FontWeight.Bold)
                    Text("Ouvre la demande système Android pour devenir l’application téléphone (dialer).",color=Muted,fontSize=10.sp,lineHeight=14.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("L’enregistrement d’appel avant décrochage n’est pas garanti : Android limite l’accès au flux audio téléphonique. Cette option mémorise ton choix, mais n’active pas un enregistrement système impossible sur certains appareils.",color=Muted,fontSize=10.sp,lineHeight=15.sp)
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).border(1.dp,Blue.copy(alpha=.18f),RoundedCornerShape(18.dp)).padding(15.dp)) {
                Column {
                    Text("À PROPOS",color=Blue,fontSize=9.sp,fontWeight=FontWeight.Bold,letterSpacing=1.6.sp)
                    Spacer(Modifier.height(5.dp)); Text("Appel + by Zelnox",color=White,fontSize=16.sp,fontWeight=FontWeight.Bold)
                    Text("Version 1.2 • Interface néon",color=Muted,fontSize=11.sp)
                    Spacer(Modifier.height(7.dp)); Text("L'app lance les appels avec l'application Téléphone et la SIM habituelle. Certaines options sont des préférences d'interface, pas des fonctions de filtrage ou de réseau.",color=Muted,fontSize=10.sp,lineHeight=15.sp)
                }
            }
        }
    }

    @Composable private fun SettingRow(label:String,detail:String,checked:Boolean,change:(Boolean)->Unit,symbol:String) {
        Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(16.dp)).background(Panel).padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically) {
            Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Blue.copy(alpha=.12f)),contentAlignment=Alignment.Center) { Text(symbol,color=Blue,fontSize=19.sp,fontWeight=FontWeight.Bold) }
            Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(label,color=White,fontSize=12.sp,fontWeight=FontWeight.SemiBold); Text(detail,color=Muted,fontSize=9.sp,lineHeight=12.sp) }
            Switch(checked=checked,onCheckedChange=change,colors=SwitchDefaults.colors(checkedThumbColor=Blue,checkedTrackColor=Blue.copy(alpha=.35f),uncheckedThumbColor=Muted))
        }
    }

    @Composable private fun EntriesList(list:List<Entry>,heading:String,subtitle:String,choose:(String)->Unit) {
        Column(Modifier.fillMaxWidth()) {
            Text(heading,color=White,fontSize=23.sp,fontWeight=FontWeight.Bold)
            Text(subtitle,color=Muted,fontSize=11.sp)
            Spacer(Modifier.height(12.dp))
            if(list.isEmpty()) Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Panel).padding(20.dp),contentAlignment=Alignment.Center) {
                Text("Aucun élément chargé. Autorise l'accès demandé pour afficher les données.",color=Muted,fontSize=12.sp,textAlign=TextAlign.Center)
            }
            LazyColumn(Modifier.fillMaxWidth().heightIn(max=600.dp)) {
                items(list) { e ->
                    Row(Modifier.fillMaxWidth().padding(vertical=4.dp).clip(RoundedCornerShape(15.dp)).background(Panel).clickable { choose(e.phone) }.padding(13.dp),verticalAlignment=Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Blue.copy(alpha=.25f),Blue2.copy(alpha=.25f)))),contentAlignment=Alignment.Center) { Text(e.name.take(1).uppercase(),color=Blue,fontWeight=FontWeight.Bold,fontSize=16.sp) }
                        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(e.name,color=White,fontSize=13.sp,fontWeight=FontWeight.SemiBold); Text(e.phone,color=Muted,fontSize=11.sp) }
                        Text("☎",color=Mint,fontSize=20.sp)
                    }
                }
            }
        }
    }


    private fun requestDefaultDialer() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val roleManager = getSystemService(RoleManager::class.java)
                if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) && !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
                    startActivityForResult(roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER), 740)
                } else toast("Appel Plus est déjà l’application téléphonique par défaut")
            } else {
                val intent = Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, packageName)
                startActivity(intent)
            }
        } catch (_: Exception) { toast("Impossible d’ouvrir le choix de l’application téléphone") }
    }

    private fun vibrate() {
        try {
            val vibrator = if(android.os.Build.VERSION.SDK_INT >= 31) getSystemService(VibratorManager::class.java).defaultVibrator else getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if(android.os.Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(18, VibrationEffect.DEFAULT_AMPLITUDE)) else { @Suppress("DEPRECATION") vibrator.vibrate(18) }
        } catch(_:Exception) {}
    }
    private fun loadContacts() {
        contacts.clear()
        val cursor=contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER),null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")
        cursor?.use { while(it.moveToNext()) contacts.add(Entry(it.getString(0) ?: "Contact",it.getString(1) ?: "")) }
    }
    private fun loadRecents() {
        recents.clear()
        val cursor=contentResolver.query(CallLog.Calls.CONTENT_URI,arrayOf(CallLog.Calls.CACHED_NAME,CallLog.Calls.NUMBER),null,null,CallLog.Calls.DATE+" DESC")
        cursor?.use { while(it.moveToNext()) recents.add(Entry(it.getString(0) ?: "Numéro",it.getString(1) ?: "")) }
    }
    private fun makeCall(number:String) {
        try { startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:"+Uri.encode(number)))) }
        catch(_:SecurityException) { toast("Android a refusé l'appel. Vérifie l'autorisation.") }
        catch(_:Exception) { toast("Impossible de lancer l'appel.") }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
