APPel Plus by ZelnoX — interface PC prototype

Sur Windows : extraire le ZIP puis ouvrir PC_AppelPlus/index.html dans Edge/Chrome. Code de validation démo : 123456.

Fonctions : navigation accueil, historique local de démonstration, contacts (ajout/suppression), clavier, stockage navigateur.

LIMITES : aucun SMS réel, aucune vérification d’identité réelle, aucune synchronisation avec l’application Android et aucun appel réel. Pour activer cela, il faut une API backend sécurisée, fournisseur SMS OTP, et service téléphonie opérateur ou VoIP/SIP. Les données stockées ici sont dans le navigateur de ce PC.
