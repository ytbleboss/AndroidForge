package com.zelnox.appelplus

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.telecom.Call
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class IncomingCallActivity : Activity() {
    companion object { @Volatile var activeCall: Call? = null }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val call = activeCall
        val incoming = intent.getBooleanExtra("incoming", call?.state == Call.STATE_RINGING)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32); setBackgroundColor(Color.rgb(7, 15, 30))
        }
        val title = TextView(this).apply {
            text = if (incoming) "Appel entrant" else "Appel en cours"
            textSize = 27f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "Appel Plus • ZelnoX\n\nL’enregistrement audio peut être restreint par Android ou le fabricant."
            textSize = 15f; setTextColor(Color.rgb(145, 160, 184)); gravity = Gravity.CENTER
        }
        root.addView(title); root.addView(info)
        if (incoming) root.addView(Button(this).apply {
            text = "Décrocher"
            setOnClickListener { try { activeCall?.answer(Call.STATE_AUDIO_ONLY) } catch (_: Exception) {}; finish() }
        })
        root.addView(Button(this).apply {
            text = if (incoming) "Refuser" else "Terminer l’appel"
            setOnClickListener { try { activeCall?.disconnect() } catch (_: Exception) {}; finish() }
        })
        root.addView(Button(this).apply {
            text = "Enregistrement d’appel"
            setOnClickListener {
                android.widget.Toast.makeText(this@IncomingCallActivity,
                    "L’audio des appels téléphoniques est protégé par Android. L’enregistrement n’est pas disponible via l’API standard sur cet appareil.",
                    android.widget.Toast.LENGTH_LONG).show()
            }
        })
        setContentView(root)
    }
}
