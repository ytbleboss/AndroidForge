# Appel + by Zelnox — projet Android

Contenu actuel :
- Clavier téléphonique et appels sortants via la SIM, avec permission Android.
- Liste des contacts depuis l'annuaire Android.
- Récents appels depuis le journal Android (permission dédiée).
- Raccourci d'ouverture de l'application SMS système.
- Options d'apparence et préférences locales persistantes.

Limites de cette édition :
- L'application n'est pas un remplacement complet du dialer système certifié; les appels entrants restent gérés par Android.
- L'anti-spam est une préférence d'interface uniquement, pas un filtre réel.
- Les SMS sont lancés dans l'application de messagerie par défaut; Appel + ne lit ni n'envoie les SMS elle-même.

Compilation APK :
1. Ouvrir le dossier dans Android Studio avec Android SDK Platform 35 installé.
2. Synchroniser Gradle (internet requis pour les plugins et bibliothèques).
3. Build > Build APK(s).
APK debug attendu : app/build/outputs/apk/debug/app-debug.apk.
