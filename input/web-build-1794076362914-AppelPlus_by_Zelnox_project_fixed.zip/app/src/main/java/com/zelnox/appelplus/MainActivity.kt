package com.zelnox.appelplus

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.CallLog
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF030611)
private val Panel = Color(0xFF0C1630)
private val Neon = Color(0xFF00A8FF)
private val White = Color(0xFFF4F7FF)

data class Entry(val name: String, val phone: String)

class MainActivity : ComponentActivity() {
    private var queuedCall by mutableStateOf("")
    private val contacts = mutableStateListOf<Entry>()
    private val recents = mutableStateListOf<Entry>()

    private val callPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) makeCall(queuedCall)
        else toast("Permission d'appel refusée")
    }
    private val contactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadContacts() else toast("Permission Contacts refusée")
    }
    private val logsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) loadRecents() else toast("Permission journal d'appels refusée")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var dial by remember { mutableStateOf("") }
            var tab by remember { mutableStateOf("Clavier") }
            val prefs = getSharedPreferences("appelplus", MODE_PRIVATE)
            var spam by remember { mutableStateOf(prefs.getBoolean("spam", true)) }
            var blueGlow by remember { mutableStateOf(prefs.getBoolean("glow", true)) }
            var vibration by remember { mutableStateOf(prefs.getBoolean("vibration", false)) }

            MaterialTheme {
                Column(Modifier.fillMaxSize().background(Night).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("♛", color=Neon, fontSize=27.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Appel +", color=Neon, fontSize=29.sp, fontWeight=FontWeight.Bold)
                            Text("by Zelnox", color=White, fontSize=14.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Text("SIM • Téléphone", color=Color.LightGray, fontSize=11.sp)
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(4.dp),
                        horizontalArrangement=Arrangement.SpaceEvenly) {
                        listOf("Clavier","Contacts","Récents","Messages","Plus").forEach { t ->
                            Text(t, color=if(tab==t) Neon else White, fontSize=11.sp,
                                modifier=Modifier.clickable {
                                    tab=t
                                    when(t) {
                                        "Contacts" -> if (checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED) loadContacts() else contactsPermission.launch(Manifest.permission.READ_CONTACTS)
                                        "Récents" -> if (checkSelfPermission(Manifest.permission.READ_CALL_LOG)==PackageManager.PERMISSION_GRANTED) loadRecents() else logsPermission.launch(Manifest.permission.READ_CALL_LOG)
                                    }
                                }.padding(vertical=10.dp, horizontal=5.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    when(tab) {
                        "Clavier" -> {
                            Box(Modifier.fillMaxWidth().border(1.dp, Neon, RoundedCornerShape(15.dp))
                                .background(Panel, RoundedCornerShape(15.dp)).padding(16.dp), contentAlignment=Alignment.Center) {
                                BasicTextField(dial, {dial=it}, keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Phone),
                                    textStyle=TextStyle(color=White,fontSize=26.sp), singleLine=true,
                                    decorationBox={ inner -> if(dial.isEmpty()) Text("Composer un numéro",color=Color.Gray,fontSize=20.sp); inner() })
                            }
                            Spacer(Modifier.height(12.dp))
                            val keys=listOf("1" to "","2" to "ABC","3" to "DEF","4" to "GHI","5" to "JKL","6" to "MNO","7" to "PQRS","8" to "TUV","9" to "WXYZ","*" to "","0" to "+","#" to "")
                            keys.chunked(3).forEach { row ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceEvenly) {
                                    row.forEach { (digit,letters) ->
                                        Column(Modifier.weight(1f).padding(4.dp).height(58.dp)
                                            .background(Panel,RoundedCornerShape(16.dp)).border(1.dp,Neon.copy(alpha=if(blueGlow).5f else .15f),RoundedCornerShape(16.dp))
                                            .clickable { dial+=digit }, horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.Center) {
                                            Text(digit,color=White,fontSize=23.sp); Text(letters,color=Color.LightGray,fontSize=9.sp)
                                        }
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly) {
                                Button(onClick={if(dial.isNotEmpty())dial=dial.dropLast(1)}, colors=ButtonDefaults.buttonColors(backgroundColor=Panel)) { Text("⌫ Effacer",color=White) }
                                Button(onClick={
                                    if(dial.isBlank()) toast("Compose un numéro") else {
                                        queuedCall=dial
                                        if(checkSelfPermission(Manifest.permission.CALL_PHONE)==PackageManager.PERMISSION_GRANTED) makeCall(dial)
                                        else callPermission.launch(Manifest.permission.CALL_PHONE)
                                    }
                                },colors=ButtonDefaults.buttonColors(backgroundColor=Color(0xFF00C853)),shape=RoundedCornerShape(30.dp)) {
                                    Text("☎ APPELER",color=Color.White,fontSize=17.sp,fontWeight=FontWeight.Bold)
                                }
                            }
                        }
                        "Contacts" -> EntriesList(contacts, "Contacts", { dial=it; tab="Clavier" })
                        "Récents" -> EntriesList(recents, "Derniers appels", { dial=it; tab="Clavier" })
                        "Messages" -> {
                            Text("Messages SMS",color=Neon,fontSize=20.sp,fontWeight=FontWeight.Bold)
                            Text("L'application ouvre l'outil SMS de ton téléphone.",color=White)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick={ try { startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)) } catch(_:Exception) { toast("Application SMS introuvable") } },
                                colors=ButtonDefaults.buttonColors(backgroundColor=Neon)) { Text("Ouvrir les SMS",color=Night) }
                        }
                        else -> {
                            Text("Options de Appel +",color=Neon,fontSize=20.sp,fontWeight=FontWeight.Bold)
                            SettingRow("Protection anti-spam (interface)",spam){spam=it;prefs.edit().putBoolean("spam",it).apply()}
                            SettingRow("Effets lumineux bleus",blueGlow){blueGlow=it;prefs.edit().putBoolean("glow",it).apply()}
                            SettingRow("Vibration clavier (préférence)",vibration){vibration=it;prefs.edit().putBoolean("vibration",it).apply()}
                            Spacer(Modifier.height(12.dp))
                            Text("Version 1.0 • by Zelnox",color=Color.LightGray)
                            Text("Les réglages sont enregistrés sur ce téléphone. La protection anti-spam est une option visuelle, pas un filtrage système.",color=Color.Gray,fontSize=12.sp)
                        }
                    }
                }
            }
        }
    }

    @Composable private fun SettingRow(label:String, checked:Boolean, change:(Boolean)->Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical=8.dp).background(Panel,RoundedCornerShape(12.dp)).padding(12.dp),
            verticalAlignment=Alignment.CenterVertically) {
            Text(label,color=White,modifier=Modifier.weight(1f),fontSize=14.sp)
            Switch(checked=checked,onCheckedChange=change,colors=SwitchDefaults.colors(checkedThumbColor=Neon))
        }
    }

    @Composable private fun EntriesList(list:List<Entry>, heading:String, choose:(String)->Unit) {
        Text(heading,color=Neon,fontSize=20.sp,fontWeight=FontWeight.Bold)
        if(list.isEmpty()) Text("Aucun élément chargé. Autorise l'accès si demandé.",color=Color.LightGray,fontSize=13.sp)
        LazyColumn {
            items(list) { e ->
                Row(Modifier.fillMaxWidth().padding(vertical=4.dp).background(Panel,RoundedCornerShape(12.dp))
                    .clickable { choose(e.phone) }.padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(e.name,color=White); Text(e.phone,color=Color.LightGray,fontSize=12.sp) }
                    Text("☎",color=Neon,fontSize=20.sp)
                }
            }
        }
    }

    private fun loadContacts() {
        contacts.clear()
        val cursor=contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER),
            null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC")
        cursor?.use { while(it.moveToNext()) contacts.add(Entry(it.getString(0) ?: "Contact",it.getString(1) ?: "")) }
    }

    private fun loadRecents() {
        recents.clear()
        val cursor=contentResolver.query(CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.CACHED_NAME,CallLog.Calls.NUMBER),null,null,CallLog.Calls.DATE+" DESC")
        cursor?.use { while(it.moveToNext()) recents.add(Entry(it.getString(0) ?: "Numéro",it.getString(1) ?: "")) }
    }

    private fun makeCall(number:String) {
        try { startActivity(Intent(Intent.ACTION_CALL,Uri.parse("tel:"+Uri.encode(number)))) }
        catch(_:SecurityException) { toast("Android a refusé l'appel. Vérifie l'autorisation.") }
        catch(_:Exception) { toast("Impossible de lancer l'appel.") }
    }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
